package com.example.autofish;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.WindowManager;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.content.Context;
import android.view.accessibility.AccessibilityEvent;

public class FishAccessibilityService extends AccessibilityService {
    private WindowManager wm;
    private View panel;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean running = false;
    private int phase = 0;
    private Runnable loop;

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {}
    @Override public void onInterrupt() { stopLoop(); removePanel(); }

    @Override public void onServiceConnected() {
        super.onServiceConnected();
        showPanel();
    }

    private void showPanel() {
        if (panel != null) return;
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(12, 8, 12, 8);
        box.setBackgroundColor(0xEE202020);
        TextView label = new TextView(this);
        label.setText("AutoFish");
        label.setTextColor(0xFFFFFFFF);
        box.addView(label);
        Button start = new Button(this);
        start.setText("СТАРТ");
        start.setOnClickListener(v -> { running = !running; start.setText(running ? "СТОП" : "СТАРТ"); if (running) runCycle(); else stopLoop(); });
        box.addView(start);
        Button close = new Button(this);
        close.setText("Скрыть");
        close.setOnClickListener(v -> removePanel());
        box.addView(close);
        panel = box;
        int type = android.os.Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.END;
        p.x = 20; p.y = 160;
        wm.addView(panel, p);
    }

    private void runCycle() {
        if (!running) return;
        // Demo only: taps near lower-center of screen at a fixed interval.
        // Coordinates are proportional to current display size.
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        int x = dm.widthPixels / 2;
        int y = (int)(dm.heightPixels * 0.90f);
        long duration = (phase % 3 == 0) ? 850 : 70;
        dispatchTapOrHold(x, y, duration);
        phase++;
        loop = () -> {
            if (!running) return;
            handler.postDelayed(this::runCycle, phase % 3 == 0 ? 1800 : 220);
        };
        handler.postDelayed(loop, duration + 100);
    }

    private void dispatchTapOrHold(int x, int y, long durationMs) {
        Path path = new Path();
        path.moveTo(x, y);
        GestureDescription.StrokeDescription stroke = new GestureDescription.StrokeDescription(path, 0, durationMs);
        GestureDescription.Builder builder = new GestureDescription.Builder().addStroke(stroke);
        dispatchGesture(builder.build(), null, null);
    }

    private void stopLoop() {
        running = false;
        handler.removeCallbacksAndMessages(null);
    }

    private void removePanel() {
        if (wm != null && panel != null) {
            try { wm.removeView(panel); } catch (Exception ignored) {}
            panel = null;
        }
    }

    @Override public boolean onUnbind(android.content.Intent intent) {
        stopLoop(); removePanel(); return super.onUnbind(intent);
    }
}
