package com.example.autofish;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.provider.Settings;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(32, 40, 32, 32);
        TextView title = new TextView(this);
        title.setText("AutoFish — тестовый прототип\n\nСервис выполняет повторяющиеся касания. Пока он НЕ распознаёт поклёвку автоматически.");
        title.setTextSize(18);
        layout.addView(title);
        Button accessibility = new Button(this);
        accessibility.setText("1. Открыть настройки специальных возможностей");
        accessibility.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        layout.addView(accessibility);
        Button overlay = new Button(this);
        overlay.setText("2. Разрешить отображение поверх других приложений");
        overlay.setOnClickListener(v -> {
            if (android.os.Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this))
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
            else startService(new Intent(this, FishAccessibilityService.class));
        });
        layout.addView(overlay);
        TextView note = new TextView(this);
        note.setText("\nПосле включения службы вернись в AutoFish. Это исходный проект для сборки в Android Studio; APK не включён.");
        note.setTextSize(14);
        layout.addView(note);
        setContentView(layout);
    }
}
